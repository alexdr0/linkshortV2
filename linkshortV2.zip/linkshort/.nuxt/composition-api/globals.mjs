export const isFullStatic = false
export const staticPath = "/mnt/f/WavelensRepositories/linkshortV2/linkshort/.nuxt/static-json"
export const publicPath = "/"
export const globalContext = "__NUXT__"
export const globalNuxt = "$nuxt"