<template>
  <div id="index-container">
    <h1>Linkshort</h1>
    <h2>Make your links shorter</h2>
    <input type="text"  class="input" v-model="data.link" placeholder="Link goes here" />
    <button class="submit" @click="submit" >
      Shorten
    </button>
    <div class="success-box" v-if="JSON.stringify(data.apidata) !== '{}'">
      <span class="announce-text">🎉 Wooh! Here's your URL:</span><span class="url-text"><u>  {{ config.host }}/{{data.apidata.return.url}}</u></span>
    </div>
    <h3>Developed by Alexander Bobo</h3>
    <a href="https://alexdr.tech"><span class="credits" href="https://alexdr.tech">See some of my other projects</span></a>

    <div class="inquiry-box">
      <h3 class="inquiries">For inquiries please email buisness@alexdr.tech</h3>
    </div>
  </div>
</template>

<script>
import { defineComponent, reactive, watchEffect } from '@nuxtjs/composition-api'
const config = require('@/config.json')

export default defineComponent({
  name: 'Home',
  setup(){
    const data = reactive({
      link: '',
      apidata: {}
    })

    watchEffect(() => {
      console.log(data.link)
    })


    function validURL(str) {
      var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
        '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
        '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
        '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
        '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
        '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
      return !!pattern.test(str);
    }


    let submit = () => {
      if(validURL(data.link) == false){
        alert("invalid url")
        return false
      }

      // check if it includes https
      if(data.link.includes("https://") == false){
        data.link = "https://" + data.link
      }
    
      console.log("Submitted")
      let myHeaders = new Headers();
      myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

      let urlencoded = new URLSearchParams();
      urlencoded.append("url", data.link);

      let requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: urlencoded,
        redirect: 'follow'
      };

      fetch(config.apihost + "/api/makeurl", requestOptions)
        .then(response => response.text())
        .then(result => {
          console.log(result)
          data.apidata = JSON.parse(result)
          console.log(data.apidata)
        })
        .catch(error => console.log('error', error));
    }

    document.addEventListener('keydown', (e) => {
      if(e.keyCode === 13){
        submit()
      }
    })

    return {
      data,
      submit,
      config
    }
  }
})
</script>

<style lang="sass">
#index-container
  background-color: #0d1117
  height: 100%
  width: 100%
  position: absolute
  top: 0
  left: 0
  right: 0
  bottom: 0
h1
  font-size: 60pt
  font-weight: bolder
  margin-top: 10%
h2
  font-size: 17pt
  color: gray
  margin-top: 20pt
.input
  width: 50%
  height: 45pt
  color: black
  margin-top: 10pt
  border-radius: 10pt
  font-family: inter
  font-weight: bold
.input:placeholder
  color: gray

.input:focus
  border: solid 2pt #0d5cd3

.submit
  width: 75pt 
  height: 45pt
  border-radius: 6px
  background-color: #0d5cd3
  box-shadow: none
  border: none 
  margin-left: 5pt
  font-family: inter
  font-weight: bold
  color: white
  margin-top: 10pt

.submit:hover
  background: #0d1117
  color: #0d5cd3
  border: 2pt solid #0d5cd3
  cursor: pointer

h3
  font-size: 12pt
  color: gray
  margin-top: 20pt

.credits
  font-size: 12pt
  color: #0d5cd3
  margin-top: 20pt
  text-decoration: none
  cursor: pointer
  text-decoration: underline
.inquiries
  font-size: 10px
.inquiry-box
  position: absolute
  width: 100%
  height: 50pt
  bottom: 0
  left: 0
  right: 0
  text-align: center
.success-box
  margin-top: 10pt
  width: calc(50% + 85pt)
  margin-left: calc(25% - 42.5pt)
  height: 50pt
  background: #009933
  border: 1pt solid #248f24
  border-radius: 10pt
  color: white
  padding-top:9.5pt

  .announce-text
    font-size: 17pt
    font-weight: bold
    margin-top: 10pt
  .url-text
    font-size: 16pt
    font-style: italic
    margin-top: 10pt

</style>
