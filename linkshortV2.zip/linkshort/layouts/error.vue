<template>
    <div>
        Hello
    </div>
</template>

<script>
// nuxt basic setup
 import { defineComponent, useRoute } from '@nuxtjs/composition-api'
const config = require('@/config.json')

export default defineComponent({
  name: 'Home',
  setup() {
    const route = useRoute()
    const path = route.value.path.substring(1, route.value.path.length)
    console.log(path)

    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

    var urlencoded = new URLSearchParams();
    urlencoded.append("uuid",  path);

    var requestOptions = {
    method: 'POST',
    headers: myHeaders,
    body: urlencoded,
    redirect: 'follow'
    };

    if(path == "undefined"){
        console.log("NOURL")
        alert("The url you entered is invalid, or there is a system error.")
    } else {
        fetch(config.apihost+"/api/getuuid", requestOptions)
        .then(response => response.text())
        .then(result => {
            window.location.href = JSON.parse(result).return;
        })
        .catch(error => console.log('error', error));
    }
    }
})
</script>